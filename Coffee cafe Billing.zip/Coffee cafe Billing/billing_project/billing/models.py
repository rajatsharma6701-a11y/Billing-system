from django.db import models

class Bill(models.Model):
    customer_name = models.CharField(max_length=100)
    customer_mobile = models.CharField(max_length=15)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Bill {self.id}"


class Item(models.Model):
    bill = models.ForeignKey(Bill, on_delete=models.CASCADE, related_name='items')
    name = models.CharField(max_length=100)
    quantity = models.IntegerField()
    price = models.FloatField()

    def total(self):
        return self.quantity * self.price
