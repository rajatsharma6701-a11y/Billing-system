from django.shortcuts import render, redirect
from .models import Bill, Item
from django.utils import timezone


def customer_page(request):
    if request.method == 'POST':
        name = request.POST['name']
        mobile = request.POST['mobile']
        bill = Bill.objects.create(
            customer_name=name,
            customer_mobile=mobile
        )
        return redirect('add_items', bill_id=bill.id)
    return render(request, 'customer.html')


def add_items(request, bill_id):
    bill = Bill.objects.get(id=bill_id)
    items = bill.items.all()

    if request.method == 'POST':

        if 'add_item' in request.POST:
            Item.objects.create(
                bill=bill,
                name=request.POST['item_name'],
                quantity=request.POST['quantity'],
                price=request.POST['price']
            )
            return redirect('add_items', bill_id=bill.id)

        if 'generate' in request.POST and items.exists():
            return redirect('bill_view', bill_id=bill.id)

    return render(request, 'items.html', {
        'bill': bill,
        'items': items
    })


def update_item(request, item_id):
    item = Item.objects.get(id=item_id)
    bill_id = item.bill.id

    if request.method == 'POST':
        item.name = request.POST['item_name']
        item.quantity = request.POST['quantity']
        item.price = request.POST['price']
        item.save()
        return redirect('add_items', bill_id=bill_id)

    return render(request, 'update_item.html', {'item': item})


def delete_item(request, item_id):
    item = Item.objects.get(id=item_id)
    bill_id = item.bill.id
    item.delete()
    return redirect('add_items', bill_id=bill_id)


def bill_view(request, bill_id):
    bill = Bill.objects.get(id=bill_id)
    items = bill.items.all()

    subtotal = sum(item.total() for item in items)
    gst_rate = 5
    gst_amount = subtotal * gst_rate / 100
    grand_total = subtotal + gst_amount

    return render(request, 'bill.html', {
        'bill': bill,
        'items': items,
        'subtotal': subtotal,
        'gst_rate': gst_rate,
        'gst_amount': gst_amount,
        'total': grand_total,
        'date': timezone.now()
    })


# 🔥 NEW: ALL BILLS PAGE
def all_bills(request):
    bills = Bill.objects.prefetch_related('items').all().order_by('-created_at')
    return render(request, 'all_bills.html', {'bills': bills})


# 🔥 NEW: DELETE BILL
def delete_bill(request, bill_id):
    bill = Bill.objects.get(id=bill_id)
    bill.delete()
    return redirect('all_bills')
